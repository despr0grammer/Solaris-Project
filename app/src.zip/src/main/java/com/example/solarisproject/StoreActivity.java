package com.example.solarisproject;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.NumberFormat;
import java.util.Locale;

public class StoreActivity extends AppCompatActivity {

    private TextView textTotalPrice;
    private Button buttonAddToCart;
    private int panelPrice = 50000;
    private int totalPrice = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store);

        // Inicializar vistas
        textTotalPrice = findViewById(R.id.text_total_price);
        buttonAddToCart = findViewById(R.id.button_add_to_cart);

        // Mostrar el precio inicial
        updateTotalPrice();

        // Configurar acción del botón "Agregar al carrito"
        buttonAddToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addToCart(panelPrice);
                updateTotalPrice();
            }
        });
    }

    // Método para agregar un producto al carrito
    private void addToCart(int price) {
        totalPrice += price;
    }

    // Método para actualizar el precio total mostrado
    private void updateTotalPrice() {
        // Formatear el precio total a formato CLP
        String formattedPrice = NumberFormat.getNumberInstance(Locale.getDefault()).format(totalPrice);
        textTotalPrice.setText(getString(R.string.clp_price_format, formattedPrice));
    }
}
