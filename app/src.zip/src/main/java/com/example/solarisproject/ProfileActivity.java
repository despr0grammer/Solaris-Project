package com.example.solarisproject;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    private TextView textName;
    private TextView textEmail;
    private TextView textPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Inicializar vistas
        textName = findViewById(R.id.profile_name);
        textEmail = findViewById(R.id.profile_email);
        textPhone = findViewById(R.id.profile_phone);

        // Cargar datos del perfil
        loadProfileData();
    }

    private void loadProfileData() {
        String name = "Diego Venegas";
        String email = "diego.venegas22@inacapmail.cl";
        String phone = "(Agregar número de teléfono)";

        // Setear los datos en las vistas
        textName.setText(name);
        textEmail.setText(email);
        textPhone.setText(phone);
    }
}
