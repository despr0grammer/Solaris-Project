package com.example.solarisproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Botón para ir al perfil del usuario
        Button profileButton = findViewById(R.id.button_profile);
        profileButton.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, ProfileActivity.class));
        });

        // Botón para ir a la tienda
        Button storeButton = findViewById(R.id.button_store);
        storeButton.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, StoreActivity.class));
        });


        // Botón para ir a configuración
        Button settingsButton = findViewById(R.id.button_settings);
        settingsButton.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, SettingsActivity.class));
        });

        // Botón para ir a emergencias
        Button emergenciesButton = findViewById(R.id.button_emergencies);
        emergenciesButton.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, EmergenciesActivity.class));
        });
    }
}
